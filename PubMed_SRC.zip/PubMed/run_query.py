# run_query.py
from pubmed_paper_fetcher.fetcher import PubMedFetcher

# Create the fetcher
fetcher = PubMedFetcher(debug=True)

# Define your query and output file
query = "cancer immunotherapy"
output_file = "results.csv"

# Run the query
papers = fetcher.run_query(query, max_results=100)

if papers:
    # Save to CSV
    fetcher.save_results_to_csv(papers, output_file)
    print(f"Results saved to {output_file}")
else:
    print("No matching papers found with pharmaceutical/biotech company authors.")