# publish.py
"""
Script to publish the module to TestPyPI
"""
import os
import subprocess
import sys

def run_command(command):
    """Run a shell command and print output"""
    print(f"Running: {command}")
    process = subprocess.Popen(
        command,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True
    )
    stdout, stderr = process.communicate()
    
    if stdout:
        print(stdout)
    if stderr:
        print(stderr)
        
    return process.returncode == 0

def publish_to_test_pypi():
    """Build and publish the package to TestPyPI"""
    # Build the package
    if not run_command("poetry build"):
        print("Failed to build the package")
        return False
        
    # Configure TestPyPI repository if not already configured
    if not run_command("poetry config repositories.testpypi https://test.pypi.org/legacy/"):
        print("Failed to configure TestPyPI repository")
        return False
        
    # Publish to TestPyPI
    # Note: You'll need to set up your API token first:
    # poetry config pypi-token.testpypi <your-token>
    if not run_command("poetry publish --repository testpypi"):
        print("Failed to publish to TestPyPI")
        return False
        
    print("Successfully published to TestPyPI!")
    print("You can install it with:")
    print("pip install --index-url https://test.pypi.org/simple/ pubmed-paper-fetcher")
    
    return True

if __name__ == "__main__":
    if not publish_to_test_pypi():
        sys.exit(1)