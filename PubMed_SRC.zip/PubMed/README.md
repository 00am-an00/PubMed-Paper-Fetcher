# PubMed Paper Fetcher

A Python tool to fetch research papers from PubMed and identify those with authors affiliated with pharmaceutical or biotech companies.

## Features

- Search PubMed using their full query syntax
- Identify papers with authors from non-academic institutions, specifically pharmaceutical and biotech companies
- Export results to CSV with detailed information
- Command-line interface with helpful options

## Code Organization

The code is organized as follows:

```
pubmed-paper-fetcher/
├── pubmed_paper_fetcher/
│   ├── __init__.py
│   ├── fetcher.py     # Core functionality for fetching and processing papers
│   └── cli.py         # Command-line interface
├── pyproject.toml     # Poetry configuration and dependencies
├── run_query.py       # Simple script for running queries directly
└── README.md          # Documentation
```

The project follows a modular structure:
- `fetcher.py` contains the `PubMedFetcher` class responsible for interacting with the PubMed API and processing the results
- `cli.py` provides the command-line interface that uses the `PubMedFetcher` class
- `run_query.py` provides a simple way to run queries directly

## Installation

### Prerequisites

- Python 3.8 or higher
- Poetry (for dependency management)

### Install using Poetry

1. Clone the repository:
```bash
git clone https://github.com/yourusername/pubmed-paper-fetcher.git
cd pubmed-paper-fetcher
```

2. Install dependencies using Poetry:
```bash
poetry install
```

This will set up all required dependencies and install the `get-papers-list` command.

### Install for Development

For development, you can install the package in editable mode:
```bash
pip install -e .
```

## Usage

### Quick Start with run_query.py

The simplest way to use the tool is with the included `run_query.py` script:

```bash
python run_query.py
```

This will:
1. Prompt you to enter your search query
2. Run the query using default settings
3. Automatically save the results to `results.csv` in the current directory

### Command-line Usage

After installation, you can use the `get-papers-list` command:

```bash
# Basic usage
poetry run get-papers-list "cancer therapy"

# Save results to a file
poetry run get-papers-list "covid-19 treatment" -f results.csv

# Enable debug mode
poetry run get-papers-list "antibody development" -d

# Specify maximum number of results
poetry run get-papers-list "gene therapy" -m 200
```

### Command-line Options

- `query`: PubMed search query (required)
- `-f, --file`: Filename to save results (CSV format)
- `-d, --debug`: Enable debug mode for verbose output
- `-m, --max-results`: Maximum number of results to return (default: 100)
- `-h, --help`: Display help message

### As a Python Module

You can also use the package as a Python module:

```python
from pubmed_paper_fetcher import PubMedFetcher

# Create a fetcher instance
fetcher = PubMedFetcher(debug=True)

# Run a query
papers = fetcher.run_query("cancer immunotherapy", max_results=50)

# Save results to CSV
fetcher.save_results_to_csv(papers, "cancer_papers.csv")
```

## CSV Output

The tool saves results in CSV format with the following columns:
- Paper ID
- Title
- Authors and their affiliations
- Publication date
- Journal
- Abstract
- Keywords
- Non-academic authors identified
- Link to the paper

By default, when using `run_query.py`, results are automatically saved to `results.csv` in the current directory. This file is updated with each new query.

## How It Works

1. The tool sends a search query to PubMed's E-utilities API
2. It fetches the matching paper IDs and retrieves detailed information for each paper
3. Papers are analyzed to identify authors with non-academic affiliations
4. The tool uses heuristics to distinguish academic from commercial affiliations
5. Results are filtered to include only papers with at least one author from a pharmaceutical or biotech company
6. Data is formatted and returned as a CSV file or printed to the console

## Tools and Libraries Used

- [requests](https://requests.readthedocs.io/) - HTTP library for API calls
- [BeautifulSoup4](https://www.crummy.com/software/BeautifulSoup/) - XML parsing library
- [pandas](https://pandas.pydata.org/) - Data manipulation and CSV handling
- [lxml](https://lxml.de/) - XML processing
- [Poetry](https://python-poetry.org/) - Dependency management and packaging
- [OpenAI GPT-4](https://openai.com/gpt-4) - Assistance with code development and logic design

## Error Handling

The tool includes robust error handling for:
- Invalid PubMed queries
- API connection issues
- Missing or malformed data in API responses
- CSV export failures

## License

This project is licensed under the MIT License - see the LICENSE file for details.