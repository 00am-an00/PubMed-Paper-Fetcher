# pubmed_paper_fetcher/fetcher.py
import re
from typing import Dict, List, Optional, Set, Tuple, Union
import logging
import time
from urllib.parse import quote_plus

import requests
from bs4 import BeautifulSoup
import pandas as pd

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pubmed_paper_fetcher")

class PubMedFetcher:
    """
    A class to fetch and process research papers from PubMed API based on user queries,
    with functionality to identify non-academic authors.
    """
    
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    ESEARCH_URL = f"{BASE_URL}/esearch.fcgi"
    EFETCH_URL = f"{BASE_URL}/efetch.fcgi"
    
    # Keywords that indicate academic affiliations
    ACADEMIC_KEYWORDS = {
        'university', 'college', 'institute', 'school', 'academia', 'academic',
        'faculty', 'laboratory', 'lab', 'department', 'center for', 'centre for',
        'hospital', 'medical center', 'clinic', 'health system', 'foundation',
        'national', 'federal', 'government', 'ministry', 'research center', 
        'academy', 'organization', 'organisation', 'nhs'
    }
    
    # Keywords that indicate pharmaceutical or biotech companies
    COMPANY_KEYWORDS = {
        'pharma', 'pharmaceutical', 'biotech', 'biopharmaceutical', 'therapeutics',
        'biologics', 'diagnostics', 'laboratories', 'inc.', 'corp', 'corporation',
        'co., ltd.', 'company', 'gmbh', 'biopharma', 'bioscience', 'biosciences',
        'health', 'technologies', 'technology', 'llc', 'ltd', 'limited', 'ag',
        'plc', 'sa', 'lifesciences', 'sciences', 'genomics', 'medicine'
    }
    
    def __init__(self, debug: bool = False):
        """
        Initialize the PubMedFetcher with debug mode.
        
        Args:
            debug: If True, enable debug logging.
        """
        self.debug = debug
        if debug:
            logger.setLevel(logging.DEBUG)
        
    def search(self, query: str, retmax: int = 100) -> List[str]:
        """
        Search for papers matching the query on PubMed.
        
        Args:
            query: The search query in PubMed syntax.
            retmax: Maximum number of results to return.
            
        Returns:
            A list of PubMed IDs matching the query.
        """
        logger.debug(f"Searching PubMed with query: {query}")
        
        params = {
            "db": "pubmed",
            "term": query,
            "retmode": "json",
            "retmax": retmax,
            "usehistory": "y"
        }
        
        try:
            response = requests.get(self.ESEARCH_URL, params=params)
            response.raise_for_status()
            
            data = response.json()
            pmids = data["esearchresult"]["idlist"]
            webenv = data["esearchresult"].get("webenv", "")
            query_key = data["esearchresult"].get("querykey", "")
            
            logger.debug(f"Found {len(pmids)} papers matching the query")
            
            return pmids, webenv, query_key
        except requests.RequestException as e:
            logger.error(f"Error searching PubMed: {e}")
            raise
            
    def fetch_paper_details(self, pmids: List[str], webenv: str = "", query_key: str = "") -> List[Dict]:
        """
        Fetch detailed information for the given PubMed IDs.
        
        Args:
            pmids: List of PubMed IDs to fetch details for.
            webenv: Web environment parameter from previous search.
            query_key: Query key parameter from previous search.
            
        Returns:
            A list of dictionaries containing paper details.
        """
        logger.debug(f"Fetching paper details for {len(pmids)} papers")
        
        results = []
        
        # Use batch processing to avoid overwhelming the API
        batch_size = 50
        
        for i in range(0, len(pmids), batch_size):
            batch = pmids[i:i+batch_size]
            
            if webenv and query_key:
                params = {
                    "db": "pubmed",
                    "query_key": query_key,
                    "WebEnv": webenv,
                    "retstart": i,
                    "retmax": batch_size,
                    "retmode": "xml"
                }
            else:
                params = {
                    "db": "pubmed",
                    "id": ",".join(batch),
                    "retmode": "xml"
                }
                
            try:
                response = requests.get(self.EFETCH_URL, params=params)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, "xml")
                articles = soup.find_all("PubmedArticle")
                
                for article in articles:
                    paper_info = self._parse_article(article)
                    if paper_info:
                        results.append(paper_info)
                
                # Be nice to the API with a short pause between batches
                if i + batch_size < len(pmids):
                    time.sleep(0.5)
                    
            except requests.RequestException as e:
                logger.error(f"Error fetching paper details: {e}")
                continue
                
        logger.debug(f"Successfully processed {len(results)} papers")
        return results
    
    def _parse_article(self, article_xml) -> Optional[Dict]:
        """
        Parse a PubMed article XML and extract relevant information.
        
        Args:
            article_xml: BeautifulSoup object containing article XML.
            
        Returns:
            Dictionary with paper details or None if parsing fails.
        """
        try:
            # Extract PubMed ID
            pmid = article_xml.find("PMID").text.strip()
            
            # Extract article title
            article_element = article_xml.find("Article")
            if not article_element:
                return None
                
            title_element = article_element.find("ArticleTitle")
            title = title_element.text.strip() if title_element else "Unknown title"
            
            # Extract publication date
            pub_date = self._extract_publication_date(article_xml)
            
            # Extract author information
            authors_info = self._extract_authors_info(article_xml)
            
            # Check if any author is from a pharmaceutical/biotech company
            non_academic_authors = []
            company_affiliations = set()
            
            for author in authors_info:
                if author.get("is_non_academic", False):
                    name = f"{author.get('lastname', '')}, {author.get('firstname', '')}"
                    non_academic_authors.append(name.strip(", "))
                    
                    if author.get("affiliation"):
                        companies = self._extract_company_names(author["affiliation"])
                        company_affiliations.update(companies)
            
            # Extract corresponding author email
            corresponding_email = self._extract_corresponding_email(article_xml)
            
            # Only return papers with at least one non-academic author
            if non_academic_authors:
                return {
                    "PubmedID": pmid,
                    "Title": title,
                    "Publication Date": pub_date,
                    "Non-academic Author(s)": "; ".join(non_academic_authors),
                    "Company Affiliation(s)": "; ".join(company_affiliations),
                    "Corresponding Author Email": corresponding_email
                }
            else:
                return None
                
        except Exception as e:
            logger.error(f"Error parsing article {article_xml.find('PMID').text if article_xml.find('PMID') else 'unknown'}: {e}")
            return None
    
    def _extract_publication_date(self, article_xml) -> str:
        """Extract and format the publication date from the article XML."""
        try:
            pub_date_element = article_xml.find("PubDate")
            if not pub_date_element:
                return "Unknown"
                
            year = pub_date_element.find("Year")
            year = year.text if year else "Unknown"
            
            month = pub_date_element.find("Month")
            month = month.text if month else "Jan"
            
            day = pub_date_element.find("Day")
            day = day.text if day else "01"
            
            # Handle text months
            try:
                if month.isalpha():
                    month_map = {
                        "Jan": "01", "Feb": "02", "Mar": "03", "Apr": "04",
                        "May": "05", "Jun": "06", "Jul": "07", "Aug": "08",
                        "Sep": "09", "Oct": "10", "Nov": "11", "Dec": "12"
                    }
                    month = month_map.get(month[:3], "01")
            except:
                month = "01"
                
            return f"{year}-{month}-{day}"
        except Exception as e:
            logger.error(f"Error extracting publication date: {e}")
            return "Unknown"
    
    def _extract_authors_info(self, article_xml) -> List[Dict]:
        """Extract author information including affiliations from the article XML."""
        authors_info = []
        
        try:
            author_list = article_xml.find("AuthorList")
            if not author_list:
                return authors_info
                
            authors = author_list.find_all("Author")
            
            for author in authors:
                author_data = {}
                
                lastname = author.find("LastName")
                author_data["lastname"] = lastname.text if lastname else ""
                
                firstname = author.find("ForeName")
                author_data["firstname"] = firstname.text if firstname else ""
                
                # Get affiliations
                affiliations = author.find_all("Affiliation")
                if affiliations:
                    author_data["affiliation"] = " | ".join([aff.text for aff in affiliations])
                    author_data["is_non_academic"] = self._is_non_academic_affiliation(author_data["affiliation"])
                else:
                    # Check if there are affiliations at the article level
                    article_affiliations = article_xml.find_all("Affiliation")
                    if article_affiliations:
                        author_data["affiliation"] = " | ".join([aff.text for aff in article_affiliations])
                        author_data["is_non_academic"] = self._is_non_academic_affiliation(author_data["affiliation"])
                    else:
                        author_data["affiliation"] = ""
                        author_data["is_non_academic"] = False
                
                authors_info.append(author_data)
                
            return authors_info
        except Exception as e:
            logger.error(f"Error extracting authors info: {e}")
            return authors_info
    
    def _is_non_academic_affiliation(self, affiliation: str) -> bool:
        """
        Determine if an affiliation is non-academic (likely a company).
        
        Args:
            affiliation: The affiliation text to analyze.
            
        Returns:
            True if the affiliation appears to be non-academic, False otherwise.
        """
        if not affiliation:
            return False
            
        affiliation_lower = affiliation.lower()
        
        # Check if any academic keywords are in the affiliation
        for keyword in self.ACADEMIC_KEYWORDS:
            if keyword in affiliation_lower:
                # If we find an academic keyword, check if it's part of a company name
                # For example "University Pharma Inc." should still be detected as a company
                if any(company_keyword in affiliation_lower for company_keyword in self.COMPANY_KEYWORDS):
                    # Additional check to distinguish company names from academic institutions
                    if re.search(r'\b(inc|corp|ltd|llc|gmbh|co|ag|sa|plc)\b', affiliation_lower):
                        return True
                    
                return False
        
        # If no academic keywords are found, check for company keywords
        for keyword in self.COMPANY_KEYWORDS:
            if keyword in affiliation_lower:
                return True
                
        # Check for email domains that might indicate a company
        email_match = re.search(r'[\w\.-]+@([\w\.-]+)', affiliation_lower)
        if email_match:
            domain = email_match.group(1)
            if '.edu' not in domain and '.gov' not in domain and '.ac.' not in domain:
                return True
                
        return False
    
    def _extract_company_names(self, affiliation: str) -> Set[str]:
        """
        Extract company names from an affiliation string.
        
        Args:
            affiliation: The affiliation text to analyze.
            
        Returns:
            A set of company names found in the affiliation.
        """
        companies = set()
        
        if not affiliation:
            return companies
            
        # Try to extract company names using patterns
        # Pattern 1: Company name followed by Inc, Ltd, etc.
        company_patterns = [
            r'([A-Z][A-Za-z0-9\s&\-\'\.]+)\s+(Inc\.?|LLC|Ltd\.?|GmbH|Corp\.?|Corporation|S\.A\.|SA|AG|plc|B\.V\.|Pty\.|Pvt\.)'
        ]
        
        for pattern in company_patterns:
            matches = re.finditer(pattern, affiliation)
            for match in matches:
                company_name = match.group(0).strip()
                companies.add(company_name)
        
        # If no matches found with patterns, return a cleaned version of the affiliation
        if not companies:
            # Split by common delimiters and take chunks that contain company keywords
            parts = re.split(r'[,;|]', affiliation)
            for part in parts:
                part = part.strip()
                part_lower = part.lower()
                
                # Check if part contains company keywords
                if any(keyword in part_lower for keyword in self.COMPANY_KEYWORDS):
                    # Don't include parts that are clearly not company names
                    if len(part) > 3 and not part.startswith("Department") and not part.startswith("Depart."):
                        companies.add(part)
        
        return companies
    
    def _extract_corresponding_email(self, article_xml) -> str:
        """Extract the corresponding author's email from the article XML."""
        try:
            # Method 1: Look for explicit electronic address in author info
            authors = article_xml.find_all("Author")
            for author in authors:
                if author.get("ValidYN") == "Y" and author.get("CorrespondingAuthor") == "Y":
                    email = author.find("ELocationID", EIdType="email")
                    if email:
                        return email.text
                        
            # Method 2: Look in the author affiliations for email addresses
            affiliations = article_xml.find_all("Affiliation")
            for affiliation in affiliations:
                if affiliation:
                    email_match = re.search(r'[\w\.-]+@[\w\.-]+', affiliation.text)
                    if email_match:
                        return email_match.group(0)
                        
            # Method 3: Look in the abstract or full text for email addresses
            abstract = article_xml.find("AbstractText")
            if abstract:
                email_match = re.search(r'[\w\.-]+@[\w\.-]+', abstract.text)
                if email_match:
                    return email_match.group(0)
                    
            # If all methods fail, return empty string
            return ""
        except Exception as e:
            logger.error(f"Error extracting corresponding email: {e}")
            return ""
    
    def run_query(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Run a complete PubMed query workflow.
        
        Args:
            query: The search query in PubMed syntax.
            max_results: Maximum number of results to return.
            
        Returns:
            A list of dictionaries with paper details.
        """
        logger.info(f"Running PubMed query: {query}")
        
        try:
            # Search for papers
            pmids, webenv, query_key = self.search(query, max_results)
            
            if not pmids:
                logger.info("No papers found matching the query")
                return []
                
            # Fetch paper details
            papers = self.fetch_paper_details(pmids, webenv, query_key)
            
            # Filter for papers with non-academic authors
            filtered_papers = [p for p in papers if p is not None]
            
            logger.info(f"Found {len(filtered_papers)} papers with non-academic authors")
            
            return filtered_papers
        except Exception as e:
            logger.error(f"Error running query: {e}")
            raise
    
    def save_results_to_csv(self, papers: List[Dict], filename: str) -> None:
        """
        Save the results to a CSV file.
        
        Args:
            papers: List of paper dictionaries.
            filename: Name of the file to save results to.
        """
        if not papers:
            logger.warning("No papers to save")
            return
            
        try:
            df = pd.DataFrame(papers)
            df.to_csv(filename, index=False)
            logger.info(f"Results saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving results to CSV: {e}")
            raise