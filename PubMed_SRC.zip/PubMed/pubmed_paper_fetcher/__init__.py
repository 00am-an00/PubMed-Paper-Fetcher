# pubmed_paper_fetcher/__init__.py
from .fetcher import PubMedFetcher

__version__ = "0.1.0"