import argparse
import sys
from typing import List, Optional
import logging

from .fetcher import PubMedFetcher

logger = logging.getLogger("pubmed_paper_fetcher.cli")

def parse_args(args: Optional[List[str]] = None) -> argparse.Namespace:
    """
    Parse command line arguments.
    
    Args:
        args: List of command line arguments. Defaults to sys.argv[1:].
        
    Returns:
        Parsed arguments namespace.
    """
    parser = argparse.ArgumentParser(
        description="Fetch PubMed papers and identify those with pharmaceutical/biotech company authors.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument(
        "query", 
        help="PubMed search query (supports full PubMed query syntax)"
    )
    
    parser.add_argument(
        "-f", "--file", 
        type=str,
        help="Filename to save results (CSV format). If not provided, results will be printed to console."
    )
    
    parser.add_argument(
        "-d", "--debug", 
        action="store_true",
        help="Enable debug mode for verbose output"
    )
    
    parser.add_argument(
        "-m", "--max-results",
        type=int,
        default=100,
        help="Maximum number of results to return"
    )
    
    return parser.parse_args(args)

def main(args: Optional[List[str]] = None) -> int:
    """
    Main entry point for the command line application.
    
    Args:
        args: Command line arguments. Defaults to sys.argv[1:].
        
    Returns:
        Exit code.
    """
    parsed_args = parse_args(args)
    
    # Configure logging
    logging.basicConfig(
        level=logging.DEBUG if parsed_args.debug else logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    
    try:
        # Create the fetcher
        fetcher = PubMedFetcher(debug=parsed_args.debug)
        
        # Run the query
        papers = fetcher.run_query(parsed_args.query, parsed_args.max_results)
        
        if not papers:
            logger.info("No matching papers found with pharmaceutical/biotech company authors.")
            return 0
        
        # Handle the results based on --file option
        if parsed_args.file:
            fetcher.save_results_to_csv(papers, parsed_args.file)
        else:
            # Print to console in a readable format
            import pandas as pd
            df = pd.DataFrame(papers)
            print(df.to_string())
        
        return 0
    
    except Exception as e:
        logger.error(f"Error running the application: {e}")
        if parsed_args.debug:
            import traceback
            traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())