# tests/test_fetcher.py
import pytest
from unittest.mock import patch, MagicMock
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup

from pubmed_paper_fetcher.fetcher import PubMedFetcher

@pytest.fixture
def fetcher():
    return PubMedFetcher(debug=True)

def test_is_non_academic_affiliation():
    fetcher = PubMedFetcher()
    
    # Test cases for non-academic affiliations
    assert fetcher._is_non_academic_affiliation("Pfizer Inc., New York, NY, USA")
    assert fetcher._is_non_academic_affiliation("Genentech, Inc., South San Francisco, CA")
    assert fetcher._is_non_academic_affiliation("AstraZeneca Pharmaceuticals, Cambridge, UK")
    assert fetcher._is_non_academic_affiliation("Moderna Therapeutics")
    assert fetcher._is_non_academic_affiliation("john.doe@company.com")
    
    # Test cases for academic affiliations
    assert not fetcher._is_non_academic_affiliation("Harvard University, Boston, MA")
    assert not fetcher._is_non_academic_affiliation("Department of Medicine, Stanford University")
    assert not fetcher._is_non_academic_affiliation("National Institutes of Health")
    assert not fetcher._is_non_academic_affiliation("john.doe@stanford.edu")
    
    # Edge cases
    assert not fetcher._is_non_academic_affiliation("")
    assert not fetcher._is_non_academic_affiliation(None)
    
    # Mixed cases
    assert fetcher._is_non_academic_affiliation("University Pharma Inc.")
    assert fetcher._is_non_academic_affiliation("Biotech Research Center Ltd.")

def test_extract_company_names():
    fetcher = PubMedFetcher()
    
    # Test extraction of company names
    companies = fetcher._extract_company_names("Pfizer Inc., New York, NY, USA")
    assert "Pfizer Inc." in companies
    
    companies = fetcher._extract_company_names("Department of Research, Genentech, Inc., South San Francisco, CA")
    assert any("Genentech" in company for company in companies)
    
    # Test with multiple companies
    companies = fetcher._extract_company_names("Moderna, Inc., Cambridge, MA; BioNTech SE, Mainz, Germany")
    assert len(companies) >= 1
    assert any("Moderna" in company for company in companies) or any("BioNTech" in company for company in companies)

@patch('requests.get')
def test_search(mock_get, fetcher):
    # Mock the response
    mock_response = MagicMock()
    mock_response.json.return_value = {
        "esearchresult": {
            "idlist": ["12345", "67890"],
            "webenv": "WEBENV",
            "querykey": "1"
        }
    }
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response
    
    # Call the method
    pmids, webenv, query_key = fetcher.search("cancer")
    
    # Assertions
    assert pmids == ["12345", "67890"]
    assert webenv == "WEBENV"
    assert query_key == "1"
    mock_get.assert_called_once()

@patch('requests.get')
def test_fetch_paper_details(mock_get, fetcher):
    # Create a simple XML response
    xml_content = """
    <PubmedArticleSet>
      <PubmedArticle>
        <MedlineCitation>
          <PMID>12345</PMID>
          <Article>
            <ArticleTitle>Test Article</ArticleTitle>
            <AuthorList>
              <Author>
                <LastName>Smith</LastName>
                <ForeName>John</ForeName>
                <Affiliation>Pfizer Inc., New York, NY</Affiliation>
              </Author>
            </AuthorList>
            <Abstract>
              <AbstractText>This is a test abstract.</AbstractText>
            </Abstract>
          </Article>
          <DateCompleted>
            <Year>2023</Year>
            <Month>01</Month>
            <Day>15</Day>
          </DateCompleted>
        </MedlineCitation>
      </PubmedArticle>
    </PubmedArticleSet>
    """
    
    # Mock the response
    mock_response = MagicMock()
    mock_response.content = xml_content
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response
    
    # Override the _parse_article method to simplify testing
    with patch.object(fetcher, '_parse_article') as mock_parse:
        mock_parse.return_value = {
            "PubmedID": "12345",
            "Title": "Test Article",
            "Publication Date": "2023-01-15",
            "Non-academic Author(s)": "Smith, John",
            "Company Affiliation(s)": "Pfizer Inc.",
            "Corresponding Author Email": ""
        }
        
        # Call the method
        results = fetcher.fetch_paper_details(["12345"])
        
        # Assertions
        assert len(results) == 1
        assert results[0]["PubmedID"] == "12345"
        assert results[0]["Company Affiliation(s)"] == "Pfizer Inc."
        mock_get.assert_called_once()

def test_parse_article():
    fetcher = PubMedFetcher()
    
    # Create a simple XML string
    xml_string = """
    <PubmedArticle>
      <MedlineCitation>
        <PMID>12345</PMID>
        <Article>
          <ArticleTitle>Test Article</ArticleTitle>
          <AuthorList>
            <Author>
              <LastName>Smith</LastName>
              <ForeName>John</ForeName>
              <Affiliation>Pfizer Inc., New York, NY</Affiliation>
            </Author>
            <Author>
              <LastName>Doe</LastName>
              <ForeName>Jane</ForeName>
              <Affiliation>Harvard University, Boston, MA</Affiliation>
            </Author>
          </AuthorList>
          <Journal>
            <JournalIssue>
              <PubDate>
                <Year>2023</Year>
                <Month>Jan</Month>
                <Day>15</Day>
              </PubDate>
            </JournalIssue>
          </Journal>
        </Article>
      </MedlineCitation>
    </PubmedArticle>
    """
    
    # Parse the XML string
    soup = BeautifulSoup(xml_string, "xml")
    
    # Call the method
    result = fetcher._parse_article(soup)
    
    # Assertions
    assert result is not None
    assert result["PubmedID"] == "12345"
    assert result["Title"] == "Test Article"
    assert "Smith, John" in result["Non-academic Author(s)"]
    assert "Doe, Jane" not in result["Non-academic Author(s)"]
    assert any("Pfizer" in company for company in result["Company Affiliation(s)"].split("; "))

@patch('pubmed_paper_fetcher.fetcher.PubMedFetcher.search')
@patch('pubmed_paper_fetcher.fetcher.PubMedFetcher.fetch_paper_details')
def test_run_query(mock_fetch, mock_search, fetcher):
    # Mock the search method
    mock_search.return_value = (["12345", "67890"], "WEBENV", "1")
    
    # Mock the fetch_paper_details method
    mock_fetch.return_value = [
        {
            "PubmedID": "12345",
            "Title": "Test Article 1",
            "Publication Date": "2023-01-15",
            "Non-academic Author(s)": "Smith, John",
            "Company Affiliation(s)": "Pfizer Inc.",
            "Corresponding Author Email": "john@example.com"
        },
        {
            "PubmedID": "67890",
            "Title": "Test Article 2",
            "Publication Date": "2023-02-20",
            "Non-academic Author(s)": "Johnson, Mary",
            "Company Affiliation(s)": "Moderna, Inc.",
            "Corresponding Author Email": "mary@example.com"
        }
    ]
    
    # Call the method
    results = fetcher.run_query("cancer", 10)
    
    # Assertions
    assert len(results) == 2
    assert results[0]["PubmedID"] == "12345"
    assert results[1]["PubmedID"] == "67890"
    mock_search.assert_called_once_with("cancer", 10)
    mock_fetch.assert_called_once_with(["12345", "67890"], "WEBENV", "1")

@patch('pandas.DataFrame.to_csv')
def test_save_results_to_csv(mock_to_csv, fetcher):
    # Sample data
    papers = [
        {
            "PubmedID": "12345",
            "Title": "Test Article 1",
            "Publication Date": "2023-01-15",
            "Non-academic Author(s)": "Smith, John",
            "Company Affiliation(s)": "Pfizer Inc.",
            "Corresponding Author Email": "john@example.com"
        }
    ]
    
    # Call the method
    fetcher.save_results_to_csv(papers, "test.csv")
    
    # Assertions
    mock_to_csv.assert_called_once_with("test.csv", index=False)